from django.contrib import admin
from .models import Example
# Register your models here.
admin.site.register(Example)