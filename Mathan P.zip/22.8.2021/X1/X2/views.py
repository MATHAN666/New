from django.shortcuts import render
from .models import Example
from .form import Examle1
from django.http import HttpResponseRedirect

# Create your views here.
def OK(request):
    if request.method == 'POST':
         n1=Examle1(request.POST)
         if n1.is_valid():
            na=n1.cleaned_data['name']
            ag=n1.cleaned_data['age']
            ex=Example(name=na,age=ag)
            ex.save()
            n1=Examle1()
    else:
        n1=Examle1()
    all_data=Example.objects.all()  
    return render(request,'adddata.html',{'form':n1,'data':all_data})

def Del(request,pk):
    if request.method=='POST':
        Example.objects.get(id=pk).delete()
        return HttpResponseRedirect('/Add/')

def Update(request,pk):
    if request.method=='POST':
        Upt=Example.objects.get(id=pk)
        Upta=Examle1(request.POST,instance=Upt)
        if Upta.is_valid():
            Upta.save()
            return HttpResponseRedirect('/Add/')
        else:
            n=Example.objects.get(id=pk)
            nn=Examle1(instance=n)
            return render(request,'update.html',{'form':nn})