from django import forms
from .models import Example


class Examle1(forms.ModelForm):
  class Meta:
         model=Example
         fields='__all__'
         widgets={
             'name':forms.TextInput(attrs={'class':'form-control'}),
             'age':forms.TextInput(attrs={'class':'form-control'})
             
         }